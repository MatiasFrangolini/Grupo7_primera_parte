package persistencia;

import modelo.Contratacion;

public class AlarmaViviendaDto extends ContratacionDto {



}
