package persistencia;

import modelo.IPersonaState;

public class ClienteJuridicoDto extends ClienteDto {
	


	public ClienteJuridicoDto() {
		super();
	}


	
}
